//: c11:Alien.java
// From 'Thinking in Java, 2nd ed.' by Bruce Eckel
// www.BruceEckel.com. See copyright notice in CopyRight.txt.
// A serializable class.
import java.io.*;

public class Alien implements Serializable {
} ///:~