README.txt file for Thinking in Java, 3rd Edition, Beta
Copyright (c)2002 by Bruce Eckel www.BruceEckel.com

This set of HTML files is designed to work with most web browsers. 
You will find here the entire book, "Thinking in Java, 3rd Edition"
in its current state.

If you put yourself on the mailing list at http://www.BruceEckel.com 
you'll be informed of updates and publication information.

Please note:

-- To start using the frames version, open "TIJ3.htm" 
    
-- To start using non-frames version, open "TIJ301.htm"
    
-- Remember that when you click on links within the document, you can 
   always use your browser's "back" arrow to return to where you 
   were reading.

-- If you're viewing this on Netscape under Linux, try going to 
   View|Character Set and selecting "Western (ISO-8859-15)."
   
-- The document uses fonts called Verdana and Georgia which are free downloads from:
   http://www.microsoft.com/typography/
