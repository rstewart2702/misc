//: c12:Alien.java
// A serializable class.
// From 'Thinking in Java, 3rd ed.' (c) Bruce Eckel 2002
// www.BruceEckel.com. See copyright notice in CopyRight.txt.
import java.io.*;
public class Alien implements Serializable {} ///:~