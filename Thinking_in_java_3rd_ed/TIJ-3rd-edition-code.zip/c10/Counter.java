//: c10:Counter.java
// From 'Thinking in Java, 3rd ed.' (c) Bruce Eckel 2002
// www.BruceEckel.com. See copyright notice in CopyRight.txt.
package c10;

public class Counter {
  int i;
  public String toString() { return Integer.toString(i); }
} ///:~
