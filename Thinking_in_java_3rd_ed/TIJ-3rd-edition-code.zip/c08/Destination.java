//: c08:Destination.java
// From 'Thinking in Java, 3rd ed.' (c) Bruce Eckel 2002
// www.BruceEckel.com. See copyright notice in CopyRight.txt.
public interface Destination {
  String readLabel();
} ///:~
