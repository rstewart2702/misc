//: com:bruceeckel:simple:Vector.java
// Creating a package.
// From 'Thinking in Java, 3rd ed.' (c) Bruce Eckel 2002
// www.BruceEckel.com. See copyright notice in CopyRight.txt.
package com.bruceeckel.simple;

public class Vector {
  public Vector() {
    System.out.println("com.bruceeckel.simple.Vector");
  }
} ///:~
