//: com:bruceeckel:simple:List.java
// Creating a package.
// From 'Thinking in Java, 3rd ed.' (c) Bruce Eckel 2002
// www.BruceEckel.com. See copyright notice in CopyRight.txt.
package com.bruceeckel.simple;

public class List {
  public List() {
    System.out.println("com.bruceeckel.simple.List");
  }
} ///:~
