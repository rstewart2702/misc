#! /bin/sh
java TextArea
java TextPane
java FileChooserTest
java LookAndFeel cross
java LookAndFeel system
java LookAndFeel motif
java CutAndPaste
java EventThreadFrame
java InvokeLaterFrame
java BeanDumper
java BangBeanTest
java BangBean2
