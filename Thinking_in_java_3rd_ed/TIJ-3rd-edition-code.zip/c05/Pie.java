//: c05:Pie.java
// The other class.
// From 'Thinking in Java, 3rd ed.' (c) Bruce Eckel 2002
// www.BruceEckel.com. See copyright notice in CopyRight.txt.

class Pie {
  void f() { System.out.println("Pie.f()"); }
} ///:~
