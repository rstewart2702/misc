//: c13:InvariantOK.java
// Indicates that the invariant test succeeded
// From 'Thinking in Java, 3rd ed.' (c) Bruce Eckel 2002
// www.BruceEckel.com. See copyright notice in CopyRight.txt.
public class InvariantOK implements InvariantState {} ///:~
