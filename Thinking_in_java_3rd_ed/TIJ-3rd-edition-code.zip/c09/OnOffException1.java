//: c09:OnOffException1.java
// From 'Thinking in Java, 3rd ed.' (c) Bruce Eckel 2002
// www.BruceEckel.com. See copyright notice in CopyRight.txt.
public class OnOffException1 extends Exception {} ///:~